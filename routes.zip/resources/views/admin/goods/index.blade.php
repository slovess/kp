@extends('admin.layout')

@section('content')
<h1>Список товаров</h1>

@if(session('success'))
    <div class="success-message">{{ session('success') }}</div>
@endif

<a href="{{ route('admin.goods.create') }}" style="display: inline-block; margin: 15px 0; font-weight: 600; font-size: 1.1rem;">
    ➕ Добавить товар
</a>

<table>
    <thead>
        <tr>
            <th>ID</th>
            <th>Название</th>
            <th>Цена</th>
            <th>Изображение</th>
            <th>Популярный</th>
            <th>Бренд</th>
            <th>Категория</th>
            <th>Локация</th>
            <th>Материал</th>
            <th>Цвет</th>
            <th>Действия</th>
        </tr>
    </thead>
    <tbody>
        @forelse($goods as $good)
            <tr>
                <td>{{ $good->id }}</td>
                <td>{{ $good->name }}</td>
                <td>{{ number_format($good->price, 2, ',', ' ') }} ₽</td>
                <td>
                    @if($good->image)
                        <img src="{{ asset('storage/' . $good->image) }}" width="80" alt="Фото товара">
                    @endif
                </td>
                <td>{{ $good->isPopular ? 'Да' : 'Нет' }}</td>
                <td>{{ $good->brand->title ?? '—' }}</td>
                <td>{{ $good->category->title ?? '—' }}</td>
                <td>{{ $good->location->title ?? '—' }}</td>
                <td>{{ $good->material->title ?? '—' }}</td>
                <td>{{ $good->color->title ?? '—' }}</td>
                <td>
                    <a href="{{ route('admin.goods.edit', $good->id) }}" title="Редактировать">✏️</a>
                    <form action="{{ route('admin.goods.destroy', $good->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit" title="Удалить" onclick="return confirm('Удалить товар?')">🗑️</button>
                    </form>
                </td>
            </tr>
        @empty
            <tr><td colspan="11" style="text-align:center;">Нет товаров</td></tr>
        @endforelse
    </tbody>
</table>

<div style="margin-top: 20px;">
    {{ $goods->links() }}
</div>
@endsection
