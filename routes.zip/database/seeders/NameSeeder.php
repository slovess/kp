<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class NameSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $ArrayOfProductNames = [
            ['Vetements "Total Fucking Darkness" Tee', 'Футболки'],
            ['Enfants Riches Déprimés Destroyed Logo Tee', 'Футболки'],
            ['Raf Simons "Virginia Creeper" T-Shirt', 'Футболки'],
            ['Chrome Hearts Cross Logo Tee', 'Футболки'],
            ['Gucci Interlocked G Cotton Shirt', 'Футболки'],

            ['Chrome Hearts Cemetery Ring', 'Украшения'],
            ['Balenciaga BB Earrings', 'Украшения'],
            ['Valentino Rockstud Choker', 'Украшения'],
            ['Chanel CC Pearl Necklace', 'Украшения'],
            ['Chrome Hearts Dagger Pendant', 'Украшения'],

            ['Yohji Yamamoto Y-3 Bomber', 'Верхняя одежда'],
            ['Raf Simons "Riot! Riot! Riot!" Parka', 'Верхняя одежда'],
            ['Balenciaga Oversized Puffer', 'Верхняя одежда'],
            ['Moncler Maya Jacket', 'Верхняя одежда'],
            ['Stone Island Ghost Piece Jacket', 'Верхняя одежда'],

            ['Nike x Raf Simons Ozweego', 'Обувь'],
            ['Adidas Y-3 Qasa', 'Обувь'],
            ['Balenciaga Triple S Sneakers', 'Обувь'],
            ['Rick Owens Geobasket', 'Обувь'],
            ['Maison Margiela Tabi Boots', 'Обувь'],

            ['Off-White Industrial Belt', 'Аксессуары'],
            ['Alyx Rollercoaster Buckle Belt', 'Аксессуары'],
            ['Prada Re-Nylon Waist Bag', 'Аксессуары'],
            ['Dior Oblique Saddle Bag', 'Аксессуары'],
            ['Chrome Hearts Wallet Chain', 'Аксессуары'],

            ['Rick Owens DRKSHDW Cargo Pants', 'Брюки'],
            ['Julius Wide Leg Trousers', 'Брюки'],
            ['Yohji Yamamoto Drop-Crotch Pants', 'Брюки'],
            ['Balenciaga Logo Joggers', 'Брюки'],
            ['Prada Nylon Tech Trousers', 'Брюки'],

            ['Raf Simons Knitted Patchwork Sweater', 'Свитеры, джемперы'],
            ['Comme des Garçons Play Striped Pullover', 'Свитеры, джемперы'],
            ['Junya Watanabe Cable-Knit Cardigan', 'Свитеры, джемперы'],
            ['Thom Browne 4-Bar Crewneck', 'Свитеры, джемперы'],
            ['Visvim Folk Knit Sweater', 'Свитеры, джемперы'],

            ['Amiri Destroyed Denim', 'Джинсы'],
            ['Dior B23 Paint-Splatter Jeans', 'Джинсы'],
            ['Valentino Rockstud Jeans', 'Джинсы'],
            ['Saint Laurent D02 Slim Fit', 'Джинсы'],
            ['Chrome Hearts Patched Denim', 'Джинсы'],

            ['Vetements Oversized Flannel', 'Рубашки'],
            ['Raf Simons "Consumed" Shirt', 'Рубашки'],
            ['Undercover "Anarchy" Button-Up', 'Рубашки'],
            ['Yohji Yamamoto Asymmetrical Shirt', 'Рубашки'],
            ['Burberry Checkered Cotton Shirt', 'Рубашки'],

            ['Prada Re-Edition 2005', 'Сумки'],
            ['Balenciaga Hourglass Bag', 'Сумки'],
            ['Jil Sander Canvas Tote', 'Сумки'],
            ['Chrome Hearts Duffle Bag', 'Сумки'],
            ['Louis Vuitton Keepall', 'Сумки']
        ];
         foreach($ArrayOfProductNames as $item) {
            Name::create([
                'title' => $item
            ]);
        }
    }
}
